﻿using MailKit.Search;
using Tata.IGetIT.Learner.Repository.Models;
using Tata.IGetIT.Learner.Service.Interfaces;

namespace Tata.IGetIT.Learner.Service.Implementation
{
    public class CourseCatalogService : ICourseCatalogService
    {
        private readonly ICourseCatalogRepo _courseCatalogRepo;
        ILogger logger = LogManager.GetCurrentClassLogger();
        public CourseCatalogService(ICourseCatalogRepo courseCatalogRepo)
        {
            if (courseCatalogRepo == null)
            {
                new ArgumentNullException("courseCatalogRepo cannot be null");
            }
            _courseCatalogRepo = courseCatalogRepo;
        }

        public async Task<IEnumerable<CourseCatalog>> GetCourseProperties(int UserID, int CourseID, List<string> ErrorsMessages)
        {
            try
            {
                var result = await _courseCatalogRepo.GetCourseProperties(UserID, CourseID);

                if (!result.Any())
                    ErrorsMessages.Add(LearnerAppConstants.NO_COURSES_FOUND);
                return result;
            }
            catch
            {
                throw;
            }
        }


        public async Task<IEnumerable<MasterCourseCategories>> GetMasterCourseCategories(List<string> ErrorsMessages)
        {
            try
            {
                var result = await _courseCatalogRepo.GetMasterCourseCategories();

                if (!result.Any())
                    ErrorsMessages.Add(LearnerAppConstants.NO_RECORDS_FOUND);
                return result;
            }
            catch
            {
                throw;
            }
        }

        public async Task<IEnumerable<CatalogCourses>> FilterCourses(int TopicID, int CatagoryID, int SubCategoryID, int SkillLevelID, int Rating, string SearchText, List<string> ErrorsMessages)
        {
            try
            {
                var result = await _courseCatalogRepo.FilterCourses(TopicID, CatagoryID, SubCategoryID, SkillLevelID, Rating, SearchText);

                if (!result.Any())
                    ErrorsMessages.Add(LearnerAppConstants.NO_RECORDS_FOUND);
                return result;
            }
            catch
            {
                throw;
            }
        }

        public async Task<IEnumerable<Assessments>> GetAssessmentsBySubCategory(int UserID, int SubcategoryID, List<string> ErrorsMessages)
        {
            try
            {
                var result = await _courseCatalogRepo.GetAssessmentsBySubCategory(UserID, SubcategoryID);

                if (!result.Any())
                    ErrorsMessages.Add(LearnerAppConstants.NO_RECORDS_FOUND);
                return result;
            }
            catch
            {
                throw;
            }
        }

        public async Task<IEnumerable<CourseTableOfContent>> GetCourseTableOfContents(int UserID, int CourseID, float Percentage, List<string> ErrorsMessages)
        {
            try
            {
                var result = await _courseCatalogRepo.GetCourseTableOfContents(UserID, CourseID, Percentage);

                if (!result.Any())
                    ErrorsMessages.Add(LearnerAppConstants.NO_RECORDS_FOUND);
                return result;
            }
            catch
            {
                throw;
            }
        }
    }
}
