﻿using Recurly;
using Recurly.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tata.IGetIT.Learner.Service.Implementation
{
    public class SubscriptionsService : ISubscriptionsService
    {
        private readonly RecurlyConfig _recurlyConfig;
        private readonly Client _reculyClient;
        ILogger logger = LogManager.GetCurrentClassLogger();
        private readonly ISubscriptionsRepo _subscriptionRepo;
        private readonly ILearningPathsService _learningPathsService;
        /// <summary>
        ///  Subscriptions service constructor initialization.
        /// </summary>
        /// <param name="recurlyConfig">Recurly payment config injected from Program.cs</param>
        public SubscriptionsService(IOptions<RecurlyConfig> recurlyConfig, ISubscriptionsRepo subscriptionsRepo, ILearningPathsService learningPathsService)
        {
            _recurlyConfig = recurlyConfig?.Value ?? throw new ArgumentNullException(LearnerAppConstants.RECURLY_CONFIG_NOT_FOUND);
            _subscriptionRepo = subscriptionsRepo ?? throw new ArgumentNullException(nameof(ISubscriptionsRepo));
            _learningPathsService = learningPathsService ?? throw new ArgumentNullException(nameof(ILearningPathsService));

            if (_recurlyConfig.ApiKey == null)
            {
                new KeyNotFoundException(LearnerAppConstants.RECURLY_KEY_IS_NULL_OR_EMPTY);
            }
            _reculyClient = new Client(_recurlyConfig.ApiKey);
        }



        public async Task<RecurlySubscriptionResponse> SubscribeWithRecurlyAsync(RecurlyPurchaseRequest request, List<string> ErrorsMessages)
        {

            try
            {
                await ConfigureAccountAsync(request);
                var account = await _reculyClient.GetAccountAsync("code-" + request.AccountId);
                if ((bool)account.HasActiveSubscription)
                {
                    var subscriptions = _reculyClient.ListAccountSubscriptions(account.Id);
                    if (subscriptions.Any())
                    {
                        var subscription = await _reculyClient.GetSubscriptionAsync(subscriptions.Data.First().Id);
                        if (subscription != null)
                        {
                            var changeReq = new SubscriptionChangeCreate()
                            {
                                PlanCode = request.Purchase.PlanCode,
                                Quantity = 1,
                                CouponCodes = string.IsNullOrEmpty(request.Purchase.Coupon) ? null : new List<string> { request.Purchase.Coupon }
                            };

                            var subscriptionChange = await _reculyClient.CreateSubscriptionChangeAsync(subscriptions.Data.First().Id, changeReq);

                            _ = await _subscriptionRepo.UpdateCartPurchase(request.CartID);

                            var response = new RecurlySubscriptionResponse()
                            {
                                PlanId = subscriptionChange.Plan.Id,
                                UUID = subscriptionChange.Id,
                                CurrencyCode = request.Purchase.CurrencyCode,
                                Cost = subscriptionChange.UnitAmount,
                                Email = request.Billing.Email,
                                Name = subscriptionChange.Plan.Name,
                                //Paths = (await _learningPathsService.GetLearningPathsByManagerAsync(request.UserId)).ToList()
                            };

                            logger.Info($"Subscription updated for account {account.Id}, plan {subscriptionChange.Plan.Id}, subscription id {subscriptions.First().Uuid}");
                            return response;
                        }
                    }
                }
                else
                {

                    Account account1 = await _reculyClient.GetAccountAsync(account.Id);
                    var subscription = new SubscriptionCreate()
                    {
                        CouponCodes = string.IsNullOrEmpty(request.Purchase.Coupon) ? null : new List<string> { request.Purchase.Coupon },
                        PlanCode = request.Purchase.PlanCode,
                        Quantity = 1,
                        Currency = request.Purchase.CurrencyCode,
                        Account = new AccountCreate()
                        {
                            Code = request.AccountId.Replace("code-", "")
                        },
                        BillingInfoId = account.BillingInfo.Id
                    };

                    var subscriptionCreate = await _reculyClient.CreateSubscriptionAsync(subscription);
                    _ = await _subscriptionRepo.UpdateCartPurchase(request.CartID);
                    var response = new RecurlySubscriptionResponse()
                    {
                        PlanId = subscriptionCreate.Plan.Id,
                        UUID = subscriptionCreate.Id,
                        CurrencyCode = request.Purchase.CurrencyCode,
                        Cost = subscriptionCreate.UnitAmount,
                        Email = subscriptionCreate.Account.Email,
                        Name = subscriptionCreate.Plan.Name,
                        ExpireDate = subscriptionCreate.ExpiresAt,
                        TrialDate = subscriptionCreate.TrialEndsAt

                        // Paths = (await _learningPathsService.GetLearningPathsByManagerAsync(request.UserId)).ToList()
                    };

                    logger.Info($"Subscription created for account {account.Id}, plan {subscriptionCreate.Plan.Id}, subscription id {subscriptionCreate.Id}");
                    return response;
                }
            }
            catch
            {
                throw;
            }
            throw new Exception($"Subscription event failure");
        }

        private async Task ConfigureAccountAsync(RecurlyPurchaseRequest request)
        {
            try
            {
                Account account = new();
                try
                {
                    account = await _reculyClient.GetAccountAsync("code-" + request.AccountId.ToString());
                }
                catch
                {
                    if (account.Id == null)
                    {
                        var accountReq = new AccountCreate()
                        {
                            Code = request.AccountId,
                            Email = request.Billing.Email,
                            FirstName = request.Billing.FirstName,
                            LastName = request.Billing.LastName,
                            Address = new Address()
                            {
                                Street1 = request.Billing.Address1,
                                Street2 = request.Billing.Address2,
                                City = request.Billing.City,
                                Region = request.Billing.State,
                                Country = request.Billing.Country,
                                PostalCode = request.Billing.Zip
                            }
                        };

                        account = await _reculyClient.CreateAccountAsync(accountReq);

                        logger.Info($"Account created for email {request.Billing.Email}");
                    }
                }

                if (account != null && account.BillingInfo == null)
                {
                    var billingInfo = new BillingInfoCreate()
                    {
                        TokenId = request.RecurlyToken
                    };
                    var reslt_temp = await _reculyClient.CreateBillingInfoAsync(account.Id, billingInfo);
                    logger.Info($"Billing info created for account id {request.AccountId} email {request.Billing.Email}");
                }
                else if (account != null && account.BillingInfo != null)
                {
                    var billingInfo = new BillingInfoCreate()
                    {
                        TokenId = request.RecurlyToken,

                    };
                    var reslt_temp = await _reculyClient.UpdateABillingInfoAsync(account.Id, account.BillingInfo.Id, billingInfo);
                    logger.Info($"Billing info created for account id {request.AccountId} email {request.Billing.Email}");
                }
            }
            catch
            {
                throw;
            }
        }

        public async Task<IEnumerable<UserSubscription>> GetUserSubscriptionsAsync(int UserID, List<string> ErrorsMessages)
        {
            var result = await _subscriptionRepo.GetUserSubscriptionsAsync(UserID);
            if (!result.Any())
                ErrorsMessages.Add(LearnerAppConstants.NO_SUBSCRIPTION);
            return result;
        }

        public async Task<IEnumerable<UsersPurchasedHistory>> GetUserPurchasedHistoryAsync(int UserID, List<string> ErrorsMessages)
        {
            try
            {
                var result = await _subscriptionRepo.GetUserPurchasedHistoryAsync(UserID);
                if (!result.Any())
                    ErrorsMessages.Add(LearnerAppConstants.NO_SUBSCRIPTION);
                return result;
            }
            catch
            {
                throw;
            }
        }

    }
}
