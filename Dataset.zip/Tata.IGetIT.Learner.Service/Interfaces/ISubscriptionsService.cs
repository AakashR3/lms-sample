﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tata.IGetIT.Learner.Service.Interfaces
{
    public interface ISubscriptionsService
    {
        public Task<IEnumerable<UserSubscription>> GetUserSubscriptionsAsync(int UserID, List<string> ErrorsMessages);
        public Task<RecurlySubscriptionResponse> SubscribeWithRecurlyAsync(RecurlyPurchaseRequest request, List<string> ErrorsMessages);

        public Task<IEnumerable<UsersPurchasedHistory>> GetUserPurchasedHistoryAsync(int UserID, List<string> ErrorsMessages);

    }
}
