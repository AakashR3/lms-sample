﻿using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;

namespace Tata.IGetIT.Learner.Web.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class CourseCatalogController : BaseController
    {
        private readonly ICourseCatalogService _courseCatalogService;
        ILogger logger = LogManager.GetCurrentClassLogger();

        public CourseCatalogController(ICourseCatalogService courseCatalogService)
        {
            _courseCatalogService = courseCatalogService ?? throw new ArgumentNullException(nameof(ICourseCatalogService));
        }
        #region GET

        #region Course
        /// <summary>
        /// To retrieve Master Course Categories
        /// </summary>
        /// <returns></returns>
        [HttpGet("MasterCourseCategories")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<MasterCourseCategories>))]
        [SwaggerResponse(400, "Bad Request", typeof(MasterCourseCategories))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<MasterCourseCategories>))]
        public async Task<IActionResult> MasterCourseCategories()
        {
            try
            {
                List<string> errorMessages = new();
                var result = await _courseCatalogService.GetMasterCourseCategories(errorMessages);
                if (errorMessages.Any())
                {
                    logger.LogDebug(LearnerAppConstants.Failure);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<MasterCourseCategories>() { Message = LearnerAppConstants.Failure });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.Success);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<MasterCourseCategories>>() { Message = LearnerAppConstants.Success, Data = result });
                }
            }
            catch (Exception ex)
            {
                logger.LogError(LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE, ex);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<MasterCourseCategories>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }
        /// <summary>
        /// To filter course categories
        /// </summary>
        /// <param name="TopicID"></param>
        /// <param name="CatagoryID"></param>
        /// <param name="SubCategoryID"></param>
        /// <param name="SkillLevelID"></param>
        /// <param name="Rating"></param>
        /// <param name="SearchText"></param>
        /// <returns></returns>
        [HttpGet("FilterCourses/{TopicID}/{CatagoryID}/{SubCategoryID}/{SkillLevelID}/{Rating}/{SearchText}")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<CatalogCourses>))]
        [SwaggerResponse(400, "Bad Request", typeof(CatalogCourses))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<CatalogCourses>))]
        public async Task<IActionResult> FilterCourses(int TopicID, int CatagoryID, int SubCategoryID, int SkillLevelID, int Rating, string SearchText="")
        {
            try
            {
                List<string> errorMessages = new();
                var result = await _courseCatalogService.FilterCourses(TopicID, CatagoryID, SubCategoryID, SkillLevelID, Rating, SearchText, errorMessages);
                if (errorMessages.Any())
                {
                    logger.LogDebug(LearnerAppConstants.Failure);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<CatalogCourses>() { Message = LearnerAppConstants.Failure });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.Success);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<CatalogCourses>>() { Message = LearnerAppConstants.Success, Data = result });
                }
            }
            catch (Exception ex)
            {
                logger.LogError(LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE, ex);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<CatalogCourses>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }

        /// <summary>
        /// To get the user's subscriptions detail
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        [HttpGet("CourseProperties/{UserID}/{CourseID}")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<CourseCatalog>))]
        [SwaggerResponse(400, "Bad Request", typeof(CourseCatalog))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<CourseCatalog>))]
        public async Task<IActionResult> CourseProperties(int UserID, int CourseID)
        {
            try
            {
                List<string> errorMessages = new();
                var result = await _courseCatalogService.GetCourseProperties(UserID, CourseID, errorMessages);
                if (errorMessages.Any())
                {
                    logger.LogDebug(LearnerAppConstants.Failure);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<CourseCatalog>() { Message = LearnerAppConstants.Failure });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.Success);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<CourseCatalog>>() { Message = LearnerAppConstants.Success, Data = result });
                }
            }
            catch (Exception ex)
            {
                logger.LogError(LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE, ex);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<CourseCatalog>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }

        /// <summary>
        /// Get Course Table of contents
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="CourseID"></param>
        /// <returns></returns>
        [HttpGet("CourseTableOfContent/{UserID}/{CourseID}/{Percentage}")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<CourseTableOfContent>))]
        [SwaggerResponse(400, "Bad Request", typeof(CourseTableOfContent))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<CourseTableOfContent>))]
        public async Task<IActionResult> CourseTableOfContent(int UserID, int CourseID, float Percentage)
        {
            try
            {
                List<string> errorMessages = new();
                var result = await _courseCatalogService.GetCourseTableOfContents(UserID, CourseID, Percentage, errorMessages);
                if (errorMessages.Any())
                {
                    logger.LogDebug(LearnerAppConstants.Failure);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<CourseTableOfContent>() { Message = LearnerAppConstants.Failure });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.Success);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<CourseTableOfContent>>() { Message = LearnerAppConstants.Success, Data = result });
                }
            }
            catch (Exception ex)
            {
                logger.LogError(LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE, ex);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<CourseTableOfContent>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }
        #endregion

        #region Assesssments
        /// <summary>
        /// To get all assessments related to the selected sub course category
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="SubcategoryID"></param>
        /// <returns></returns>
        [HttpGet("Assessments/{UserID}/{SubcategoryID}")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<Assessments>))]
        [SwaggerResponse(400, "Bad Request", typeof(Assessments))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<Assessments>))]
        public async Task<IActionResult> Assessments(int UserID, int SubcategoryID)
        {
            try
            {
                List<string> errorMessages = new();
                var result = await _courseCatalogService.GetAssessmentsBySubCategory(UserID, SubcategoryID, errorMessages);
                if (errorMessages.Any())
                {
                    logger.LogDebug(LearnerAppConstants.Failure);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<Assessments>() { Message = LearnerAppConstants.Failure });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.Success);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<Assessments>>() { Message = LearnerAppConstants.Success, Data = result });
                }
            }
            catch (Exception ex)
            {
                logger.LogError(LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE, ex);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<Assessments>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }
        #endregion

        #endregion

    }
}
