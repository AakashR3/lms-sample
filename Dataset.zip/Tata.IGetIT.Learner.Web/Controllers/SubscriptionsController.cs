﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;

namespace Tata.IGetIT.Learner.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubscriptionsController : BaseController
    {
        private readonly ISubscriptionsService _subscriptionService;
        ILogger logger = LogManager.GetCurrentClassLogger();
        public SubscriptionsController(ISubscriptionsService subscriptionsService)
        {

            _subscriptionService = subscriptionsService ?? throw new ArgumentNullException(nameof(ISubscriptionsService));
        }

        #region GET
        /// <summary>
        /// To get the user's subscriptions detail
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        [HttpGet("Subscriptions/{UserID}")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<UserSubscription>))]
        [SwaggerResponse(400, "Bad Request", typeof(UserSubscription))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<UserSubscription>))]
        public async Task<IActionResult> Subscription(int UserID)
        {
            try
            {
                List<string> errorMessages = new();
                var result = await _subscriptionService.GetUserSubscriptionsAsync(UserID, errorMessages);
                if (errorMessages.Any())
                {
                    logger.LogDebug(LearnerAppConstants.SUBSCRIPTION_FOUND);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<UserSubscription>() { Message = LearnerAppConstants.NO_SUBSCRIPTION });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.NO_SUBSCRIPTION);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<UserSubscription>>() { Message = LearnerAppConstants.SUBSCRIPTION_FOUND, Data = result });
                }
            }
            catch (Exception ex)
            {
                logger.LogError(LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE, ex);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<UserSubscription>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }


        /// <summary>
        /// To get the user's Purchased History detail
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        [HttpGet("PurchasedHistory/{UserID}")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<UsersPurchasedHistory>))]
        [SwaggerResponse(400, "Bad Request", typeof(UsersPurchasedHistory))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<UsersPurchasedHistory>))]
        public async Task<IActionResult> PurchasedHistory(int UserID)
        {
            try
            {
                List<string> errorMessages = new();
                var result = await _subscriptionService.GetUserPurchasedHistoryAsync(UserID, errorMessages);
                if (errorMessages.Any())
                {
                    logger.LogDebug(LearnerAppConstants.PURCHASE_HISTORY_NOT_FOUND);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<UsersPurchasedHistory>() { Message = LearnerAppConstants.PURCHASE_HISTORY_NOT_FOUND });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.PURCHASE_HISTORY_FOUND);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<UsersPurchasedHistory>>() { Message = LearnerAppConstants.PURCHASE_HISTORY_FOUND, Data = result });
                }
            }
            catch (Exception ex)
            {
                logger.LogError(LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE, ex);
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<UserSubscription>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }













        #endregion


        #region POST

        [HttpPost("recurly")]
        [SwaggerResponse(200, "Ok", typeof(ReturnResponse<RecurlySubscriptionResponse>))]
        [SwaggerResponse(400, "Bad Request")]
        [SwaggerResponse(500, "Internal Server Error")]
        public async Task<IActionResult> SubscribeAsync(RecurlyPurchaseRequest request)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    logger.LogError(LearnerAppConstants.MODEL_VALIDATION_FAILED, new ApiException("Recurly purchase model validation failed"));
                    return await PopulateModelErrorsAsync();
                }
                List<string> errorMessage = new();
                var response = await _subscriptionService.SubscribeWithRecurlyAsync(request, errorMessage);

                return Ok(new ReturnResponse<RecurlySubscriptionResponse>() { Message = LearnerAppConstants.SUBSCRIPTION_FOUND, Data = response });

            }
            catch (Exception ex)
            {
                if (ex.Source.ToUpper().Equals("RECURLY"))
                {
                    if (LearnerAppConstants.RECURLY_INVALID_COUPON_CODE.Contains(ex.Message.ToString()))
                    {
                        logger.LogError(string.Format(LearnerAppConstants.INVALID_COUPON_CODE, nameof(RecurlyCardCheckout)), ex);
                        return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<Response>() { Message = LearnerAppConstants.INVALID_COUPON_CODE });
                    }
                    else if (LearnerAppConstants.RECURLY_GENERAL_EXCEPTION.Contains(ex.Message.ToString()))
                    {
                        logger.LogError(string.Format(LearnerAppConstants.GENERAL_EXCEPTION, nameof(RecurlyCardCheckout)), ex);
                        return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<Response>() { Message = LearnerAppConstants.GENERAL_EXCEPTION });
                    }
                    else if (LearnerAppConstants.RECURLY_ADDRESS_CITY_COUNTRY_EMPTY.Contains(ex.Message.ToString()))
                    {
                        logger.LogError(string.Format(LearnerAppConstants.ADDRESS_CITY_COUNTRY_EMPTY, nameof(RecurlyCardCheckout)), ex);
                        return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<Response>() { Message = LearnerAppConstants.ADDRESS_CITY_COUNTRY_EMPTY });
                    }
                    else
                    {
                        logger.LogError(string.Format(LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE, nameof(RecurlyCardCheckout)), ex);
                        return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<Response>() { Message = ex.Message.ToString() });
                    }
                }
                else
                {
                    logger.LogError(string.Format(LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE, nameof(RecurlyCardCheckout)), ex);
                    return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<Response>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });

                }
            }

        }

        #endregion
    }
}
