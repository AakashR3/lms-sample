﻿using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using Tata.IGetIT.Learner.Repository.Models;

namespace Tata.IGetIT.Learner.Web.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class TranscriptController : BaseController
    {
        private readonly ITranscriptService _transcriptService;
        ILogger logger = LogManager.GetCurrentClassLogger();

        public TranscriptController(ITranscriptService transcriptService)
        {
            _transcriptService = transcriptService ?? throw new ArgumentNullException(nameof(ITranscriptService));
        }
        #region GET

        /// <summary>
        /// To get Transcript user details
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        [HttpGet("TranscriptUserDetails/{UserID}")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<TranscriptUserDetails>))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<TranscriptUserDetails>))]
        public async Task<IActionResult> TranscriptUserDetails(int UserID)
        {
            try
            {
                List<string> errorMsg = new();
                var result = await _transcriptService.GetTranscriptUserDetails(UserID, errorMsg);
                if (result.Any())
                {
                    logger.LogDebug(LearnerAppConstants.Success);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<TranscriptUserDetails>>() { Message = LearnerAppConstants.Success, Data = result });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.Failure);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<TranscriptUserDetails>() { Message = LearnerAppConstants.Failure, Data = { } });
                }
            }
            catch (Exception ex)
            {
                logger.LogDetails(new LogDetails(LogType.Error)
                {
                    Message = LearnerAppConstants.EXCEPTION_MESSAGE,
                    AppException = ex,
                    AppUrl = Request.GetDisplayUrl()
                });
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<TranscriptUserDetails>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }
        /// <summary>
        /// To get Transcript Course History
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="CategoryID"></param>
        /// <returns></returns>
        [HttpGet("TranscriptCourseHistory/{UserID}/{CategoryID}")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<TranscriptCourseHistoryParent>))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<TranscriptCourseHistoryParent>))]
        public async Task<IActionResult> TranscriptCourseHistory(int UserID, int CategoryID)
        {
            try
            {
                List<string> errorMsg = new();
                var result = await _transcriptService.GetTranscriptCourseHistory(UserID, CategoryID,errorMsg);
                if (result.Any())
                {
                    logger.LogDebug(LearnerAppConstants.Success);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<TranscriptCourseHistoryParent>>() { Message = LearnerAppConstants.Success, Data = result });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.Failure);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<TranscriptCourseHistoryParent>() { Message = LearnerAppConstants.Failure, Data = { } });
                }
            }
            catch (Exception ex)
            {
                logger.LogDetails(new LogDetails(LogType.Error)
                {
                    Message = LearnerAppConstants.EXCEPTION_MESSAGE,
                    AppException = ex,
                    AppUrl = Request.GetDisplayUrl()
                });
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<TranscriptCourseHistoryParent>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }
        /// <summary>
        /// To get Transcript Assessment History
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="CategoryID"></param>
        /// <returns></returns>
        [HttpGet("TranscriptAssessmentHistory/{UserID}/{CategoryID}")]
        [SwaggerResponse(200, "Ok", typeof(IEnumerable<TranscriptAssessmmentHistoryParent>))]
        [SwaggerResponse(500, "Internal Server Error", typeof(IEnumerable<TranscriptAssessmmentHistoryParent>))]
        public async Task<IActionResult> TranscriptAssessmentHistory(int UserID, int CategoryID)
        {
            try
            {
                List<string> errorMsg = new();
                var result = await _transcriptService.GetTranscriptAssessmentHistory(UserID, CategoryID, errorMsg);
                if (result.Any())
                {
                    logger.LogDebug(LearnerAppConstants.Success);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<IEnumerable<TranscriptAssessmmentHistoryParent>>() { Message = LearnerAppConstants.Success, Data = result });
                }
                else
                {
                    logger.LogDebug(LearnerAppConstants.Failure);
                    return StatusCode((int)HttpStatusCode.OK, new ReturnResponse<TranscriptAssessmmentHistoryParent>() { Message = LearnerAppConstants.Failure, Data = { } });
                }
            }
            catch (Exception ex)
            {
                logger.LogDetails(new LogDetails(LogType.Error)
                {
                    Message = LearnerAppConstants.EXCEPTION_MESSAGE,
                    AppException = ex,
                    AppUrl = Request.GetDisplayUrl()
                });
                return StatusCode((int)HttpStatusCode.InternalServerError, new ReturnResponse<TranscriptAssessmmentHistoryParent>() { Message = LearnerAppConstants.GENERIC_EXCEPTION_MESSAGE });
            }
        }
        #endregion
    }
}
