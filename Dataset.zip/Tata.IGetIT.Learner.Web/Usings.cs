﻿global using NLog;
global using Tata.IGetIT.Learner.Repository.Constants;
global using Tata.IGetIT.Learner.Repository.Helpers;
global using Tata.IGetIT.Learner.Repository.Models;
global using Tata.IGetIT.Learner.Service.Helpers;
global using Tata.IGetIT.Learner.Service.Interfaces;
global using Tata.IGetIT.Web.Learner.Controllers;
global using ILogger = NLog.ILogger;