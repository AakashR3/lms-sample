using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tata.IGetIT.Learner.Repository.Models.Configurations
{
    public class SSOConfig
    {
        /// <summary>
        /// Redirect Url
        /// </summary>
        /// 
        public string RedirectUrl { get; set; }
    }
}
