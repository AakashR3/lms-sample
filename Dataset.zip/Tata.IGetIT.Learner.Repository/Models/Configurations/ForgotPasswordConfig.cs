﻿namespace Tata.IGetIT.Learner.Repository.Models.Configurations
{
    public class ForgotPasswordConfig
    {
        public string BaseURL { get; set; }
    }
}
