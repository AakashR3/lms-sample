﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tata.IGetIT.Learner.Repository.Models
{
    public class TechTips
    {
        public string ArticleID { get; set; }
        public string Title { get; set; }
        public string SubCategory { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string UserName { get; set; }
        public DateTime SubmittedDate { get; set; }
        public int Status { get; set; }
        public int UserID { get; set; }
        public int AccountID { get; set; }
        public int CategoryID { get; set; }
        public int SubCategoryID { get; set; }
        public int TopicID { get; set; }
        public int UserTypeID { get; set; }
    }
    public class TechTipsGridDataParent
    {
        public int TotalItems { get; set; }
        public int TotalPages { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public IEnumerable<TechTips> TechTipsData { get; set; }
    }
    public class Topics
    {
        public int TopicID { get; set; }
        public string TopicName { get; set; }
    }
    //Title
    //UserName
    //SubmittedDate
    //Status
    //UserID
    //AccountID
    //CategoryID
    //SubCategoryID
    //TopicID
    //ArticleID
    //Subcategory
    //UserTypeID
    //ModifiedBy

}
