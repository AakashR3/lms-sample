﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tata.IGetIT.Learner.Repository.Models
{
    public class UserSubscription
    {
        public string SubscriptionID { get; set; }
        public string SubscriptionName { get; set; }
    }
    public class UsersPurchasedHistory
    {
        public int SNo { get; set; }
        public int FulfillmentID { get; set; }
        public int SubscriptionID { get; set; }
        public string SubscriptionName { get; set; }
        public string PurchaseDate { get; set; }
        public string ExpireDate { get; set; }
        public string SalesOrderDetailID { get; set; }
    }


}
