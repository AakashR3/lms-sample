﻿namespace Tata.IGetIT.Learner.Repository.Constants
{
    public static class StoredProcedures
    {
        #region Authentication and Authorization
        public const string AUTH_USER_REGISTRATION = "login_Register_V2";
        public const string CHECK_LOGIN = "login_CheckLogin_V2";
        public const string PASSWORD_RECOVERY_REQUEST = "usr_PasswordRecoveryRequest_V2";
        public const string PASSWORD_RECOVERY_RESET = "usr_PasswordRecoveryReset_V2";

        public const string RESET_USER_PASSWORD_BY_USERID = "usr_ChangePasswordByUserId_V2";


        public const string SOCIAL_VALIDATION = "social_Validation_V2";
        public const string REGISTRATION_OTP = "registration_OTP_Generation_V2";



        public const string LOGIN_LOGOUT = "login_Logout_V2";
        public const string RESET_PASSWORD_LINK_VALIDATION_V2 = "usr_Reset_Password_Link_Validation_V2";
        public const string REGISTRATION_OTP_VERIFICATION_V2 = "registration_OTP_Verification_V2";
        public const string IS_USER_EXISTS_V2 = "IsUserExists_V2";
        #endregion

        #region SSO
        public const string GET_ACCOUNTID_BY_DOMAIN_NAME = "app_Get_AccountID_ByDomain_V2";
        public const string APP_SSO_INFO = "app_SSOInfo";
        public const string APP_SSO_LOGGING = "app_SSOLogging";
        public const string LOGIN_CHECK_AD_LOGIN = "login_CheckADLogin";
        public const string LOGIN_SSO_REGISTER = "login_SSORegister";
        public const string APP_SSO_UPDATE_USERDETAILS = "app_SSOUpdateUserDetails_V2";
        public const string SSO_LOGIN_VALIDATION = "app_LoginValidation_V2";
        #endregion

        #region Dashboard

        public const string DASHBOARD_GETTRENDINGSUBSCRIPTION = "learn_GetTrendingSubscription_V2";
        public const string DASHBOARD_GETNEWCOURSELIST = "learn_GetNewCoursesList_V2";
        public const string DASHBOARD_GETCATALOG = "learn_GetCatalog_V2";
        public const string DASHBOARD_GETSCORECARD = "app_GetDashboardMetrics_V2";
        public const string DASHBOARD_GETINPROGRESSCOURSELIST = "learn_GetInProgressCourseList_V2";
        public const string DASHBOARD_GETLEARNINGPATH = "lp_GetLearningPath_V2";
        public const string DASHBOARD_GETRECOMMENDEDCOURSELIST = "learn_GetRecommendedCourseList_V2";
        public const string DASHBOARD_GETPEERSCOURSELIST = "learn_GetPeersCourseList_V2";
        public const string DASHBOARD_GETUPCOMINGEVENTLIST = "learn_GetUpcomingEventList_V2";
        public const string DASHBOARD_GETPROFILEDATA = "learn_GetProfileData_V2";
        public const string DASHBOARD_GETTRANSCRIPTLIST = "learn_GetTranscriptList_V2";
        public const string DASHBOARD_GETPOPULARROLES = "learn_GetPopularRoles_V2";
        public const string GET_LEADING_USERS = "rp_GetLeaderBoard_V2";
        public const string DASHBOARD_GETTIMESPENTMETRICS = "learn_GetTimeSpentMetrics_V2";
        public const string DASHBOARD_GETTIMESPENTGRAPH = "learn_GetTimeSpentGraph_V2";
        public const string DASHBOARD_GET_POPULAR_ROLE_GRAPH = "learn_GetPopularRoleGraph_V2";

        #endregion Dashboard

        #region Headers and Menus

        public const string GetMenuItems = "GetMenuItems_V2";
        public const string GetPoints = "GetUserPoints_V2";
        public const string GetUserCartCount = "GetUserCartCount_V2";
        public const string GetUserNotifications = "GetUserNotifications_v2";
        public const string GetFavorites = "lp_GetUserFavorites";
        public const string CheckTrialUser = "usr_IsPaidTrialUser_V2";
        public const string GetSubscriptions = "sub_GetUsersSubscriptions_V2";

        #endregion

        #region Hero Section
        public const string GetCurrentRole = "GetCurrentRole_V2";
        public const string GetSkillset = "GetSkillset_V2";
        public const string GetCurrentLevel = "GetCurrentLevel_V2";
        public const string GetCareerPath = "GetCareerPath_V2";
        public const string GetTargetRoleCareerPath = "GetTargetRoleCareerPath_V2";
        public const string GetTargetRoleCareerPathPercentage = "GetTargetRoleCareerPathPercentage_V2";
        public const string GetTargetRole = "GetTargetRole_V2";
        public const string GetTargetRoleCurrentLevel = "GetTargetRoleCurrentLevel_V2";
        #endregion

        #region Payment

        public const string GET_CURRENCY = "plan_GetCurrency_V2";
        public const string PLAN_GET_PLANID = "plan_GetPlanID";
        public const string PLAN_SAVEPURCHASED_PLANINFO = "plan_SavePurchasedPlanInfo_V2";
        public const string SUB_INSERT_SALESFULFILLMENT = "sub_InsertSalesFulfillment";
        public const string SUB_INSERT_SALESFULFILLMENT_V2 = "sub_InsertSalesFulfillment_V2";
        public const string SUB_CANCEL_SUBSCRIPTION = "sub_InsertInvoiceLog";
        public const string PLAN_UPDATE_PAYMENT = "plan_UpdatePayment";
        public const string PLAN_GET_SUBSCRIPTIONID = "plan_Get_SubscriptionID_V2";
        public const string SUB_UPDATE_FULFILLMENT = "sub_UpdateFulfillment";
        public const string PLAN_GETACTIVE_PLANS = "plan_GetActiveplans_V2";

        public const string SUB_VERIFYAUTORENEW = "sub_VerifyAutoRenew";
        public const string SUB_EXPIREFULFILLMENT = "sub_ExpireFulfillment";
        public const string GET_PAID_TRIAL_SUBID = "wwww_GetPaidTrialSubID";

        #endregion

        #region Cart
        public const string GET_COUNTRY_LIST = "plan_GetCountryList_V2";
        public const string GET_CART_ITEMS = "plan_GetCartItems_V2";
        public const string GET_USER_SHIPPING_INFORMATION = "plan_GetUserShipping_V2";
        public const string ADD_CART_ITEM = "plan_AddToCart_V2";
        public const string DELETE_CART_ITEM = "plan_DeleteCartItem_V2";
        public const string UPDATE_CART_PURCHASE = "plan_UpdateCartPurchase_V2";
        public const string GET_PLAN_SUBSCRIPTION_DETAIL = "PlanSubscriptionInfo_V2";

        public const string VALIDATE_TRIAL_ACCOUNT = "plan_Validate_TrialAccount_V2";


        #endregion

        #region UserSubscription
        public const string GET_SUBSCRIPTION_DETAILS = "GetUserSubscriptions_V2";
        public const string GET_USERS_PURCHASED_HISTORY = "sub_GetUsersPurchasedHistory_V2";
        #endregion

        #region TechTips
        public const string GET_TECH_TIPS = "kb_GetArticleList_V2";
        public const string GET_TOPICS = "app_GetTopics";
        #endregion

        #region Course Catalog
        public const string GET_ALL_COURSE_PROPERTIES = "lp_GetAllCourseProperties_v2";
        public const string GET_COURSE_PROPERTIES = "lp_GetCourseProperties"; // test-to be removed
        public const string GET_CATALOG_COURSES = "wwwGetCourseList_v2"; //"lp_GetCoursesBySubcategory";
        public const string GET_COURSE_FOR_LearningPath = "lp_GetCoursesBySubcategory";
        public const string GET_COURSE_Table_OF_CONTENTS = "crs_GetTableOfContent_V2";

        public const string GET_ASSESSMENTS_BY_SUBCATEGORY = "lp_GetAssessmentsBySubcategory";
        #endregion

        #region LearningPaths
        public const string GET_LEARNING_PATHS_BY_MANAGER = "lp_GetLPByManager";
        #endregion

        #region QuickStart

        public const string QUICKSTART_GETQUICKSTARTGRIDDATA = "live_LiveYouTubeTrackingData_V2";
        public const string QUICKSTART_GETCATEGORY = "app_GetCategories_V2";
        public const string QUICKSTART_GETSUBCATEGORY = "app_GetSubCategories_V2";
        public const string QUICKSTART_GETQUICKSARTNEWRELEASENOTIFICATION = "acc_GetNotificationFlagValue_V2";
        public const string QUICKSTART_UPDATEQUICKSARTNEWRELEASENOTIFICATION = "acc_UpdateJunctionUserNotification_V2";

        #endregion QuickStart

        #region Transcript
        public const string GET_TRANSCRIPT_USER_DETAILS = "rp_GetMyReportInfo_V2";
        public const string GET_TRANSCRIPT_COURSE_HISTORY = "rp_GetMyReportCourse_V2";
        public const string GET_TRANSCRIPT_ASSESSMENT_HISTORY = "rp_GetMyReportAssessment_V2";
        //rp_DownloadTranscript_V2

        #endregion

        #region UserProfile

        public const string USERPROFILE_GETPERSONALPROFILE = "usr_GetUserProfile_V2";
        public const string USERPROFILE_GETBUSINESSPROFILE = "usr_GetUserProfile_V2";
        public const string USERPROFILE_GETNOTIFICATIONSETTINGS = "usr_GetUserProfileSettings_V2";
        public const string USERPROFILE_UPDATENOTIFICATIONSETTINGS = "usr_UpdateNotificationSetting_V2";
        public const string USERPROFILE_UPDATEPERSONALPROFILE = "usr_UpdatePersonalProfile_V2";
        public const string USERPROFILE_UPDATEBUSINESSPROFILE = "usr_UpdateBusinessProfile_V2";
        public const string USERPROFILE_GETBUSINESSMANAGER = "usr_GetBusinessManagerByUserID_V2";
        public const string USERPROFILE_GETCOUNTRY = "app_GetCountryList_V2";
        public const string USERPROFILE_GETSTATEBYCOUNTRY = "app_GetStateList_V2";
        public const string USERPROFILE_GETINDUSTRYINFO = "app_GetIndustryInfo_V2";
        public const string USERPROFILE_GETCADAPPLICATIONLIST = "app_GetCadApplicationList_V2";
        public const string USERPROFILE_GETUSERGROUPS = "acc_GetGroupNamesForUser_V2";

        #endregion UserProfile

        #region Learning

        public const string LEARNING_GETHISTORY = "lp_GetUserHistory_V2";
        public const string LEARNING_GETLEARNINGPATH = "lp_GetMyLearningPath_V2";
        public const string LEARNING_GETMYLEARNING = "lp_GetMyLearning_V2";
        public const string LEARNING_ADDFAVORITEITEM = "lp_AddFavoriteItem_V2";
        public const string LEARNING_REMOVEFAVORITEITEM = "lp_RemoveFavoriteItem_V2";

        #endregion Learning
    }

    public static class Tables
    {
        public const string USER = "User_Sample";
    }
}