﻿using Tata.IGetIT.Learner.Repository.Constants;
using Tata.IGetIT.Learner.Repository.Core;
using Tata.IGetIT.Learner.Repository.Interface;
using Tata.IGetIT.Learner.Repository.Models;
using Tata.IGetIT.Learner.Repository.Models.Database.DTO;

namespace Tata.IGetIT.Learner.Repository.Implementation
{
    public class SubscriptionsRepo : ISubscriptionsRepo
    {
        private readonly IDatabaseManager _databaseOperations;
        public SubscriptionsRepo(IDatabaseManager databaseOperations)
        {
            _databaseOperations = databaseOperations;
        }

        public async Task<IEnumerable<UserSubscription>> GetUserSubscriptionsAsync(int UserID)
        {

            var param = new Dictionary<string, object>
            {
                { "@UserID", UserID }
            };
            QueryInfo queryInfo = new QueryInfo()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.GET_SUBSCRIPTION_DETAILS,
                Parameters = param
            };

            return await _databaseOperations.GetMultipleRecords<UserSubscription>(queryInfo);

        }


        public async Task<IEnumerable<UsersPurchasedHistory>> GetUserPurchasedHistoryAsync(int UserID)
        {

            var param = new Dictionary<string, object>
            {
                { "@UserID", UserID }
            };
            QueryInfo queryInfo = new QueryInfo()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.GET_USERS_PURCHASED_HISTORY,
                Parameters = param
            };

            return await _databaseOperations.GetMultipleRecords<UsersPurchasedHistory>(queryInfo);

        }

        /// <summary>
        /// Insert OTP details
        /// </summary>
        /// <param name="CartID"></param>
        /// <returns></returns>
        public async Task<int> UpdateCartPurchase(int CartID)
        {
            var param = new Dictionary<string, object>
            {
                { "@CartID", CartID }
            };

            QueryInfo queryInfo = new QueryInfo()
            {

                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.UPDATE_CART_PURCHASE,
                Parameters = param
            };

            return await _databaseOperations.ExecuteScalarAsyncInteger(queryInfo);
        }









    }
}
