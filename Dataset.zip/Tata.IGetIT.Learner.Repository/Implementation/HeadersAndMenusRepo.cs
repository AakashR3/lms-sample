﻿using Dapper;
using System.Data;
using Tata.IGetIT.Learner.Repository.Constants;
using Tata.IGetIT.Learner.Repository.Core;
using Tata.IGetIT.Learner.Repository.Interface;
using Tata.IGetIT.Learner.Repository.Models;
using Tata.IGetIT.Learner.Repository.Models.Database.DTO;
using static Dapper.SqlMapper;

namespace Tata.IGetIT.Learner.Repository.Implementation
{
    public class HeadersAndMenusRepo : IHeadersAndMenusRepo
    {
        private readonly IDatabaseManager _databaseOperations;
        public HeadersAndMenusRepo(IDatabaseManager databaseOperations)
        {
            _databaseOperations = databaseOperations;
        }

        public async Task<SqlMapper.GridReader> AllUserNotification(int UserID)
        {
            var queryParameters = new Dictionary<string, object>
            {
                { "@UserID", UserID }
            };

            QueryInfo queryInfo = new()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.GetUserNotifications,
                Parameters = queryParameters
            };

             return await _databaseOperations.GetMultipleAsync(queryInfo);
            
        }

        public Task<TrialUserDetails> CheckTrialUser(int UserID)
        {


            var queryParameters = new Dictionary<string, object>
            {
                { "@UserID", UserID }
            };

            QueryInfo queryInfo = new()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.CheckTrialUser,
                Parameters = queryParameters
            };

            return _databaseOperations.GetFirstRecordAsync<TrialUserDetails>(queryInfo);
        }

        public Task<IEnumerable<HeadersAndMenu_MoreActions_Favorites>> GetFavorites(int UserID)
        {

            var queryParameters = new Dictionary<string, object>
            {
                { "@UserID", UserID }
            };

            QueryInfo queryInfo = new()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.GetFavorites,
                Parameters = queryParameters
            };

            return _databaseOperations.GetMultipleRecords<HeadersAndMenu_MoreActions_Favorites>(queryInfo);
        }

        public Task<IEnumerable<HeadersAndMenu_MoreActions_Subscription_Child>> GetSubscriptions(int UserID)
        {

            var queryParameters = new Dictionary<string, object>
            {
                { "@UserID", UserID }
            };

            QueryInfo queryInfo = new()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.GetSubscriptions,
                Parameters = queryParameters
            };

            return _databaseOperations.GetMultipleRecords<HeadersAndMenu_MoreActions_Subscription_Child>(queryInfo);
        }

        public Task<IEnumerable<HeadersAndMenu_UserMenu>> MenuItems(int UserID)
        {
            var queryParameters = new Dictionary<string, object>
            {
                { "@UserID", UserID }
            };

            QueryInfo queryInfo = new()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.GetMenuItems,
                Parameters = queryParameters
            };

            return _databaseOperations.GetMultipleRecords<HeadersAndMenu_UserMenu>(queryInfo);
        }

        public Task<HeadersAndMenu_UserPoints> Points(int UserID, Guid SessionID)
        {
            var queryParameters = new Dictionary<string, object>
            {
                { "@UserID", UserID },
                { "@SessionID", SessionID }
            };

            QueryInfo queryInfo = new()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.GetPoints,
                Parameters = queryParameters
            };

            return _databaseOperations.GetFirstRecordAsync<HeadersAndMenu_UserPoints>(queryInfo);
        }

        public Task<int> UserCartCount(int UserID)
        {
            var queryParameters = new Dictionary<string, object>
            {
                { "@UserID", UserID }
            };

            QueryInfo queryInfo = new()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.GetUserCartCount,
                Parameters = queryParameters
            };

            return _databaseOperations.ExecuteScalarAsyncInteger(queryInfo);
        }

        public Task<IEnumerable<HeadersAndMenu_UserNotifications>> UserNotification(int UserID)
        {
            var queryParameters = new Dictionary<string, object>
            {
                { "@UserID", UserID }
            };

            QueryInfo queryInfo = new()
            {
                queryType = QueryType.StoredProcedure,
                QueryText = StoredProcedures.GetUserNotifications,
                Parameters = queryParameters
            };

            return _databaseOperations.GetMultipleRecords<HeadersAndMenu_UserNotifications>(queryInfo);
        }

    }
}
