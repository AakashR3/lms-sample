﻿using Tata.IGetIT.Learner.Repository.Constants;
using Tata.IGetIT.Learner.Repository.Core;
using Tata.IGetIT.Learner.Repository.Interface;
using Tata.IGetIT.Learner.Repository.Models;
using Tata.IGetIT.Learner.Repository.Models.Database.DTO;

namespace Tata.IGetIT.Learner.Repository.Implementation
{
    public class TranscriptRepo : ITranscriptRepo
    {
        private readonly IDatabaseManager _databaseOperations;
        public TranscriptRepo(IDatabaseManager databaseOperations)
        {
            _databaseOperations = databaseOperations;
        }

        public Task<IEnumerable<TranscriptAssessmmentHistory>> GetTranscriptAssessmentHistory(int UserID, int CategoryID)
        {
            try
            {
                var param = new Dictionary<string, object>
                {
                    { "@UserID", UserID },
                    { "@CategoryID", CategoryID }
                };
                QueryInfo queryInfo = new QueryInfo()
                {
                    queryType = QueryType.StoredProcedure,
                    QueryText = StoredProcedures.GET_TRANSCRIPT_ASSESSMENT_HISTORY,
                    Parameters = param
                };

                var result = _databaseOperations.GetMultipleRecords<TranscriptAssessmmentHistory>(queryInfo);

                return result;
            }
            catch
            {
                throw;
            }
        }

        public Task<IEnumerable<TranscriptCourseHistory>> GetTranscriptCourseHistory(int UserID, int CategoryID)
        {
            try
            {
                var param = new Dictionary<string, object>
                {
                    { "@UserID", UserID },
                    { "@CategoryID", CategoryID }
                };
                QueryInfo queryInfo = new QueryInfo()
                {
                    queryType = QueryType.StoredProcedure,
                    QueryText = StoredProcedures.GET_TRANSCRIPT_COURSE_HISTORY,
                    Parameters = param
                };

                var result = _databaseOperations.GetMultipleRecords<TranscriptCourseHistory>(queryInfo);

                return result;
            }
            catch
            {
                throw;
            }
        }

        public Task<IEnumerable<TranscriptUserDetails>> GetTranscriptUserDetails(int UserID)
        {
            try
            {
                var param = new Dictionary<string, object>
                {
                    { "@UserID", UserID }
                };
                QueryInfo queryInfo = new QueryInfo()
                {
                    queryType = QueryType.StoredProcedure,
                    QueryText = StoredProcedures.GET_TRANSCRIPT_USER_DETAILS,
                    Parameters = param
                };

                var result = _databaseOperations.GetMultipleRecords<TranscriptUserDetails>(queryInfo);

                return result;
            }
            catch
            {
                throw;
            }
        }
    }
}
