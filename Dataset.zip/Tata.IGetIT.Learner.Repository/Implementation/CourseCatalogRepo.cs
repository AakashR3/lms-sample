﻿using Tata.IGetIT.Learner.Repository.Constants;
using Tata.IGetIT.Learner.Repository.Core;
using Tata.IGetIT.Learner.Repository.Interface;
using Tata.IGetIT.Learner.Repository.Models;
using Tata.IGetIT.Learner.Repository.Models.Database.DTO;

namespace Tata.IGetIT.Learner.Repository.Implementation
{
    public class CourseCatalogRepo : ICourseCatalogRepo
    {
        private readonly IDatabaseManager _databaseOperations;
        public CourseCatalogRepo(IDatabaseManager databaseOperations)
        {
            _databaseOperations = databaseOperations;
        }

        public Task<IEnumerable<CatalogCourses>> FilterCourses(int TopicID, int CatagoryID, int SubCategoryID, int SkillLevelID, int Rating, string SearchText)
        {

            try
            {
                var param = new Dictionary<string, object>
                {
                    { "@TopicID", TopicID },
                    { "@CatagoryID", CatagoryID },
                    { "@SubCategoryID", SubCategoryID },
                    { "@SkillLevelID", SkillLevelID },
                    { "@Rating", Rating },
                    { "@SearchText", SearchText }
                };
                QueryInfo queryInfo = new()
                {
                    queryType = QueryType.StoredProcedure,
                    QueryText = StoredProcedures.GET_CATALOG_COURSES,
                    Parameters = param
                };

                var result = _databaseOperations.GetMultipleRecords<CatalogCourses>(queryInfo);

                return result;
            }
            catch
            {
                throw;
            }
        }

        public Task<IEnumerable<Assessments>> GetAssessmentsBySubCategory(int UserID, int SubcategoryID)
        {
            try
            {

                var param = new Dictionary<string, object>
                {
                    { "@UserID", UserID },
                    { "@SubcategoryID", SubcategoryID }
                };
                QueryInfo queryInfo = new()
                {
                    queryType = QueryType.StoredProcedure,
                    QueryText = StoredProcedures.GET_ASSESSMENTS_BY_SUBCATEGORY,
                    Parameters = param
                };

                var result = _databaseOperations.GetMultipleRecords<Assessments>(queryInfo);

                return result;
            }
            catch
            {
                throw;
            }
        }

        public Task<IEnumerable<CourseCatalog>> GetCourseProperties(int UserID, int CourseID)
        {
            try
            {
                var param = new Dictionary<string, object>
                {
                    { "@UserID", UserID },
                    { "@CourseID", CourseID }
                };
                QueryInfo queryInfo = new()
                {
                    queryType = QueryType.StoredProcedure,
                    QueryText = StoredProcedures.GET_ALL_COURSE_PROPERTIES,
                    Parameters = param
                };

                var result = _databaseOperations.GetMultipleRecords<CourseCatalog>(queryInfo);

                return result;
            }
            catch
            {
                throw;
            }
        }

        public Task<IEnumerable<CourseTableOfContent>> GetCourseTableOfContents(int UserID, int CourseID, float Percentage)
        {

            try
            {
                var param = new Dictionary<string, object>
                {
                    { "@UserID", UserID },
                    { "@CourseID", CourseID },
                    { "@Percentage", Percentage }
                };
                QueryInfo queryInfo = new()
                {
                    queryType = QueryType.StoredProcedure,
                    QueryText = StoredProcedures.GET_COURSE_Table_OF_CONTENTS,
                    Parameters = param
                };

                var result = _databaseOperations.GetMultipleRecords<CourseTableOfContent>(queryInfo);

                return result;
            }
            catch
            {
                throw;
            }
        }

        public Task<IEnumerable<MasterCourseCategories>> GetMasterCourseCategories()
        {
            try
            {
                var param = new Dictionary<string, object>
                {
                };
                QueryInfo queryInfo = new()
                {
                    queryType = QueryType.StoredProcedure,
                    QueryText = StoredProcedures.DASHBOARD_GETCATALOG,
                    Parameters = param
                };

                var result = _databaseOperations.GetMultipleRecords<MasterCourseCategories>(queryInfo);

                return result;
            }
            catch
            {
                throw;
            }
        }


    }
}
